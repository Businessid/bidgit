<!-- jquery -->   
        <script src="js/jquery-3.3.1.min.js"></script>
        <!-- all plugins JS hear -->    
        <script src="js/popper.min.js"></script> 
        <script src="js/tether.min.js"></script> 
        <script src="js/bootstrap.min.js"></script> 
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.mainmenu.js"></script> 
        <script src="js/plugins.js"></script>
    <!-- main JS -->    
        <script src="js/main.js"></script>
        <script src="js/zoom-slider.js"></script>
        <script type="text/javascript">
                $(document).ready( function () {
                    //If your <ul> has the id "glasscase"
                    $('#glasscase').glassCase({ 'thumbsPosition': 'bottom'});
                });
        </script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script type="text/javascript">
  $(document).ready(
    function(){
   $(".multipleSelect2").select2({
      placeholder: "enter input here" //placeholder
    });
    }
    );
</script>
 