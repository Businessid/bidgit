<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <title>Business ID Dubai Government | Ministry of foreign affairs | Dubai Immigration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width"/>
  <meta name="apple-mobile-web-app-capable" content="yes"/>
  <meta name="description" content="Business ID Dubai Government | Ministry of foreign affairs | Dubai Immigration">
  <meta name="keywords" content="business,business,freebusiness,free video,free movie,labour,activities,news,uae news,dubai news,sharja news,abu dhabi, news,business,businessid,business id,Ministry dubai,dubai business,Ministry of foreign,
  uea business,uae businessid,uae businessid,ministry">
  <meta name="author" content="Business ID">
  <meta property="og:image" content="http://businessid.net/desktop/assets/img/cover.jpg" />
  <meta property="og:description" content="Business ID Dubai Government | Ministry of foreign affairs | Dubai Immigration" />
  <meta property="og:url"content="http://businessid.net/desktop/" />
  <meta property="og:title" content="Business ID" />
  <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
  <link rel="icon" type="image/x-icon" href="http://www.businessid.net/desktop/assets/img/favicon.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/ionicons.min.css" />
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/common.css?v=1.2" />
  <link rel="stylesheet" href="css/bidstyle1.css?v=1.2" />
  <link rel="stylesheet" href="css/responsive.css?v=1.2" />
  <!-- shejin -->
  <link href="css/smart_wizard.css" rel="stylesheet" type="text/css" />
  <link href="css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="css/cv-style.css"> 
  <link rel="stylesheet" href="css/select2.min.css">
  <link rel="stylesheet" href="css/zoom-slider.css">
  <link rel="stylesheet" href="css/track-order.css">
  <link rel="stylesheet" href="css/nice-select.css">
  <link rel="stylesheet" href="css/hero-nav.css">
  <link rel="stylesheet" href="css/large-screen.css"> 
  <!-- shejin -->
  <link rel="stylesheet" href="css/home.css?v=1.3" />
  </head>