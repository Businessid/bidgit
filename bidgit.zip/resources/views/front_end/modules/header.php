  <link rel="stylesheet" href="{{ URL::asset('front_end/font-awesome/css/font-awesome.min.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/ionicons.min.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/owl.carousel.min.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/owl.theme.default.min.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/common.css?v=1.2') }}" />
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/bidstyle1.css?v=1.2') }}" />
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/responsive.css?v=1.2') }}" />
  <!-- shejin -->
  <link href="{{ URL::asset('front_end/css/smart_wizard.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ URL::asset('front_end/css/smart_wizard_theme_arrows.css') }}" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/cv-style.css') }}"> 
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/select2.min.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/zoom-slider.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/track-order.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/nice-select.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/hero-nav.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/large-screen.css') }}"> 
  <!-- shejin -->
  <link rel="stylesheet" href="{{ URL::asset('front_end/css/home.css?v=1.3') }}" />