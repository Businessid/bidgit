<div class="bx-tp-hdr" id="mainNav">  
    <nav class="navbar navbar-expand-sm offcanvas-desktop bid-nav">
      <!-- <a class=" navbar-toggle" href="JavaScript:;"  data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas" style="">
        <span class="fa-stack fa-2x has-badge" data-count="5">
          <i class="fa fa-bars fa-stack-1x fa-inverse"></i>
        </span>
      </a> -->
      <a class="navbar-brand" href="index.php"><img src="images/bid-2-logo.png" alt="www.businessid.net" title="www.businessid.net"></a>
      <div class="navbar-collapse">
        <ul class="navbar-nav mr-auto resp-mob-hd">
            <li class="nav-item active">
                <a class="nav-link min-wid-chck navbar-toggle" href="store.php"  data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">Store<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link min-wid-chck" href="#">Jobs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link min-wid-chck" href="#">Tenders</a>
            </li>

        </ul>
        <ul class="top-right-nav">
            <!-- <li class="nav-item">
                <a class="nav-link frame-lnk" href="{{ url('/register') }}">Register</a>
            </li> -->
            <!-- <li class="nav-item">
               <div class="bx-tp-sele-swtch"> 
                 <div class="dropdown">
                    <a class="dropdown-toggle switching-lnk" id="Switching-id" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img src="images/bid-2-logo.png" class="img-fluid">business ID
                    </a>
                      <div class="dropdown-menu" aria-labelledby="Switching-id">
                        <a class="dropdown-item" href="http://www.uaect.com/" target="_blank"><img src="images/uaeclogo.png" class="img-fluid">uaect</a>
                      </div>
                    </div>
               </div>
            </li> -->
             <!-- <li class="nav-item dropdown dsp-h-mob">
                  <span class="up-arrow">&nbsp;</span>
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="business ID Notification">
                  <span class="cst-icn-spn-1"><i class="material-icons tp-icn">view_module</i></span>
                </a>
                <div class="dropdown-menu switching notification-block" aria-labelledby="navbarDropdownMenuLink">
                  
                    
                </div>
            </li> -->
            <li class="nav-item dropdown dsp-h-mob">
                  <span class="up-arrow">&nbsp;</span>
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="business ID Notification">
                  <span class="cst-icn-spn-1"><i class="material-icons not-icn">notifications</i></span>
                </a>
                <div class="dropdown-menu switching notification-block" aria-labelledby="navbarDropdownMenuLink1">
                  <div class="notification-cnt">
                    <div class="hd-tp-bx-1">
                      <div class="txt-st-1">
                          <span class="txt-st-1-sp">Notifications</span>
                      </div>
                    </div>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a1.jpeg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Marrie jane<span class="sb-txt-1">Added New produt</span> in Bussiness id Store</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a4.jpg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Hamdad Elamankat<span class="sb-txt-1">Added New Jobs</span> in Bussiness id Jobs</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a3.jpeg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Spouse dizzoze<span class="sb-txt-1">Added New Tender</span> in Bussiness id Tender</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a4.jpg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Camel cat<span class="sb-txt-1">Added New wall feed</span> in His wall</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a1.jpeg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Marrie jane<span class="sb-txt-1">Added New produt</span> in Bussiness id Store</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <a href="#" class="prf-blk-sb-lnk">
                       <div class="clearfix">
                         <div class="row">
                           <div class="col-sm-3">
                             <span class="icn-tp-13"><img src="images/a1.jpeg" alt="#" title="#"></span>
                           </div>
                           <div class="col-sm-9">
                             <span class="prf-blk-sb-lnk-des">Hamdad Elamankat<span class="sb-txt-1">Added New Jobs</span> in Bussiness id Jobs</span>
                           </div>
                         </div>
                       </div>
                     </a>
                     <div class="prof-btn-wrap-1">
                       <a href="#" class="sign-out-btn-1">View All</a>
                     </div>
                  </div>
                    
                </div>
            </li>
            <li class="nav-item dropdown dsp-h-mob">
              <span class="up-arrow">&nbsp;</span>
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="business ID cart">                 
                  <span class="cst-icn-spn-1"><i class="material-icons cart-icn">shopping_cart</i></span>
                </a>
                <div class="dropdown-menu switching cart-block" aria-labelledby="navbarDropdownMenuLink2">
                  <div class="cart-block-cnt">
                    <div class="cart-tp-bx">
                      <img src="images/cart-top.png" class="img-fluid" alt="business id cart" title="#">
                      <div class="txt-st-1">My Cart</div>
                    </div>
                    <div class="purch-box-1">
                      <div class="bx-tp-prc-itm">
                        <table style="height: 80px;">
                          <tbody>
                            <tr>
                              <td class="align-middle">
                                <img src="images/nike1.jpg" class="img-product" alt="business id cart" title="#">
                              </td>
                              <td class="align-middle">
                                <div class="prf-tp-bx-1-r-1">Rotary Easy Push Multifuction Magic Broom Sweeper</div>
                                <span class="remove-btn">Remove</span>
                              </td>
                              <td class="align-middle">
                                <div class="amt-no-1">1 X 120.AED</div>
                              </td>
                            </tr>

                          </tbody>
                        </table>
                        <table style="height: 80px;">
                          <tbody>
                            <tr>
                              <td class="align-middle">
                                <img src="images/nike2.jpg" class="img-product" alt="business id cart" title="#">
                              </td>
                              <td class="align-middle">
                                <div class="prf-tp-bx-1-r-1">Rotary Easy Push Multifuction Magic Broom Sweeper</div>
                                <span class="remove-btn">Remove</span>
                              </td>
                              <td class="align-middle">
                                <div class="amt-no-1">1 X 120.AED</div>
                              </td>
                            </tr>
                            
                          </tbody>
                        </table>
                        <table style="height: 80px;">
                          <tbody>
                            <tr>
                              <td class="align-middle">
                                <img src="images/nike3.jpg" class="img-product" alt="business id cart" title="#">
                              </td>
                              <td class="align-middle">
                                <div class="prf-tp-bx-1-r-1">Rotary Easy Push Multifuction Magic Broom Sweeper</div>
                                <span class="remove-btn">Remove</span>
                              </td>
                              <td class="align-middle">
                                <div class="amt-no-1">1 X 120.AED</div>
                              </td>
                            </tr>
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="prof-btn-wrap-1">
                       <a href="#" class="sign-out-btn-1">Complete Purchasing</a>
                     </div>
                  </div>
                    
                </div>
            </li>
            <li class="nav-item dropdown dsp-h-mob">
              <span class="up-arrow">&nbsp;</span>
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="business ID profile">
                  <span class="cst-icn-spn-1"><!-- <i class="material-icons tp-icn">face</i> -->
                    <span class="no-prf-spn">K</span>
                  </span>
                </a>
                <div class="dropdown-menu switching profile-block" aria-labelledby="navbarDropdownMenuLink3">
                  <div class="profile-block-cnt">
                   <div class="prf-tp-bx-1">
                     <div class="clearfix">
                       <a href="#" class="prf-ph-tp-1">
                         <div class="prf-ph-tp-1-cnt">
                           <img src="images/decap.jpg" title="business ID Account" class="" alt="bussiness id">
                         </div>
                       </a>
                       <div class="prf-tp-bx-1-r">
                         <div class="prf-tp-bx-1-r-1">Ijas Np</div>
                         <div class="prf-tp-bx-1-r-2">ijas.prof@gmail.com</div>
                         <div class="prf-tp-bx-1-r-3">settings</div>
                         <a class="prf-tp-bx-1-r-4" href="edit-profile.php" target="_blank">My Account</a>
                       </div>
                     </div>
                   </div>
                  </div>
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">card_giftcard</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">My Products</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">work</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">My Jobs</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">gavel</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">My Tenders</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">shopping_basket</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">My Store</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">build</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">Settings</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <a href="#" class="prf-blk-sb-lnk">
                     <div class="clearfix">
                       <div class="row">
                         <div class="col-sm-3">
                           <span class="icn-tp-13"><i class="material-icons mat-icn-tp-1">play_for_work</i></span>
                         </div>
                         <div class="col-sm-9">
                           <span class="prf-blk-sb-lnk-des">Edit</span>
                         </div>
                       </div>
                     </div>
                   </a> 
                   <div class="prof-btn-wrap-1">
                     <a href="#" class="sign-out-btn-1">Sign Out</a>
                   </div>
                </div>
            </li>
            <!-- <li class="nav-item">
                <a class="nav-link frame-lnk" href="{{ url('/login') }}">Login</a>
            </li> -->
            
        </ul>
      </div>
    </nav>
</div>

  